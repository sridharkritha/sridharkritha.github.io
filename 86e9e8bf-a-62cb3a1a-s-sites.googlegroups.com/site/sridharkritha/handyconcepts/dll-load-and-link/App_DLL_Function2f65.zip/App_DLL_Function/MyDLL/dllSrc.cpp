#include "dllHeader.h"

// Create Object
 DLLCALL ImyMath* _cdecl CreateMathObject() {
	return new MyMath();
}

 int MyMath::Add(int a, int b) {
	return a+b;
}

 int MyMath::Subtract(int a, int b) {
	return a-b;
}





