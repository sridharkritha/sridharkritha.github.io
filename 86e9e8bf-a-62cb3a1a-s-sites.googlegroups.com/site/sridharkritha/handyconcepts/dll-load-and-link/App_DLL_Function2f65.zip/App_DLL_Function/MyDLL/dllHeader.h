/*
__declspec(dllexport) : (dll side)
		 You are defining a class implementation within a dll. You want another program to use the class. 
		 Here you use dllexport as you are creating a class that you wish the dll to expose.

__declspec(dllimport):  (Application side)
		  You are using a function provided by a dll. You include a header supplied with the dll. 
		  Here the header uses dllimport to bring in the implementation to be used by the current program.

Often the same header file is used in both cases and a macro defined. The build configuration defines the macro to be import or export depending which it needs.

*/



/* (PROJECTNAME)_EXPORTS - is a macro defined(enabled) local to the project. 
So MYDLL_EXPORTS  is enabled while compile MyDLL project for creating the MyDLL.dll.
But if you refer the same dllHeader.h file from the Application project then MYDLL_EXPORTS is undefined
so application see the calling convention as  __declspec(dllimport) unlike MyDLL project which sees the 
calling convention as __declspec(dllexport)
*/ 
#ifdef  MYDLL_EXPORTS 
#define DLLCALL __declspec(dllexport)   /* Should be enabled before compiling .dll project for creating the .dll*/
#else
#define DLLCALL __declspec(dllimport)  /* Should be enabled in Application side for using already created .dll*/
#endif

// Explicit dll Linking Method ( LoadLibrary(),  GetProcAddress() &  FreeLibrary() )

// Exporting Class using VTable ( Basis concept of COM )
class ImyMath {
public:
virtual ~ImyMath() {;}
virtual int Add(int a, int b) = 0;
virtual int Subtract(int a, int b) = 0;
};

// Unlike exporting global functions by undecorated name. C++ Member function are not exported directly by function names. Because
// C++ member functions are strongly decorated by default. Even declaring extern "C" around the C++ class will not avoid the member function name decoration.
// Only possible solution is exporting the C++ member functions using VTable ( This method is the basis of COM). Create one interface class having all pure 
// functions which are used as a indirect functions for calling the concrete class member function through inheritance and virtual function.  
class MyMath: public ImyMath {
public:
	MyMath() {}
	int Add(int a, int b);
	int Subtract(int a, int b);
	int a,b;
};

//  Factory function that will return the new object instance. (Only function should be declared with DLLCALL)
extern "C" /*Important for avoiding Name decoration*/
{
	DLLCALL ImyMath* _cdecl CreateMathObject();
};

// Function Pointer Declaration of CreateMathObject() [Entry Point Function]
typedef ImyMath* (*CREATE_MATH) ();

	
// Reference: http://cppcodetips.wordpress.com/
// http://www.intelliproject.net/articles/showArticle/index/using_dll_cpp