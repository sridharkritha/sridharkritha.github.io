#include <iostream>
#include <windows.h>
#include "MyDLL\dllHeader.h"

int main()
{
	HINSTANCE hDLL = LoadLibrary(L"Debug\\MyDLL.dll"); // L".\Debug\MyDLL.dll"

	if (hDLL == NULL) {
		std::cout << "Failed to load library.\n";
	}
	else {
		CREATE_MATH pEntryFunction = (CREATE_MATH)GetProcAddress(hDLL,"CreateMathObject");
		ImyMath* pMath = pEntryFunction();
		if (pMath) {
			std::cout << "10+10=" << pMath->Add(10, 10) << std::endl;
			std::cout << "50-10=" << pMath->Subtract(50, 10) << std::endl;
		}
		FreeLibrary(hDLL);
	}
	std::cin.get();
	return 0;
}