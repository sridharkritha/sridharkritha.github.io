#include <iostream>
#include <windows.h>
#include "MyDLL\dllHeader.h"

typedef int (*funcAdd) (int, int);
typedef int (*funcSubtract) (int, int);

int main()
{
	HINSTANCE hDLL = LoadLibrary(L"Debug\\MyDLL.dll"); // L".\Debug\MyDLL.dll"

	if (hDLL == NULL) {
		std::cout << "Failed to load library.\n";
	}
	else {
		funcAdd Add = (funcAdd)GetProcAddress(hDLL, "Add");
		funcSubtract Subtract = (funcSubtract)GetProcAddress(hDLL, "Subtract");

		if (Add)
			std::cout << "10+10=" << Add(10, 10) << std::endl;

		if (Subtract)
			std::cout << "50-10=" << Subtract(50, 10) << std::endl;

		FreeLibrary(hDLL);
	}

	std::cin.get();
	return 0;
}