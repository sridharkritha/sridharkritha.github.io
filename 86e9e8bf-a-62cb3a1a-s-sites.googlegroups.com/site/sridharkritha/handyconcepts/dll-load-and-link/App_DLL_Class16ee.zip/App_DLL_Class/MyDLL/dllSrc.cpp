#include "dllHeader.h"

int Add(int a, int b) {
	return a+b;
}

 int Subtract(int a, int b) {
	return a-b;
}


