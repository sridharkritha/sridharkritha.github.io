
//#define WINDOWS
//#define POSIX


#include "BMutex.hpp"
#include "BThread.hpp"
#include "BSemaphore.hpp"
#include "BSleep.hpp"

#include <iostream>

//
// This file shows how to use thread and mutex
//

// A simple thread with 1s sleep
class BTestThread : public BThread{
public:
	void run(){
		std::cout<<"\t\t [T]I am going to Sleep"<<std::endl;
		BSleep::sleep(2000);
		std::cout<<"\t\t [T]Okay I quit now"<<std::endl;
	}
};

// A simple thread which waits a mutex
class BMutexThread : public BThread{
public:
	BMutex *tex;
	
	BMutexThread(BMutex* in_tex){
		tex = in_tex;
	}
	
	void run(){
		std::cout<<"\t\t [T]Lock Mutex"<<std::endl;
		tex->lock();
		std::cout<<"\t\t [T]Mutex Unlocked -> exit"<<std::endl;
	}
};


int main(){
	BTestThread th;	
	std::cout<<"Execute sleep-thread"<<std::endl;
	th.start();
	std::cout<<"Wait thread to finish"<<std::endl;
	BSleep::sleep(50); // To be sure that the thread has started before I wait!
	th.wait();
	std::cout<<"Thread has Finished"<<std::endl;
	
	std::cout<<"-----------------------------------------"<<std::endl;
	
	std::cout<<"Create and lock mutex"<<std::endl;
	BMutex tex;
	tex.lock();
	BMutexThread mth(&tex);
	std::cout<<"Start the second thread"<<std::endl;
	mth.start();
	std::cout<<"Sleep (the thread is wainting the mutex :)"<<std::endl;
	BSleep::sleep(1000);
	std::cout<<"Release the mutex"<<std::endl;
	tex.unlock();
	
#ifdef WINDOWS
	char c;
	std::cin>>c;
#endif
	
	// In POSIX
	// To do the thing correclty we need to quit with pthread_exit(NULL);
	// But there is a wait() in the thread destructor so it is okay!
	
	return 0;
}

/*
Mac OS :
$ ./test 
Execute sleep-thread
Wait thread to finish
		 [T]I am going to Sleep
		 [T]Okay I quit now
Thread has Finished
-----------------------------------------
Create and lock mutex
Start the second thread
Sleep (the thread is wainting the mutex :)
		 [T]Lock Mutex
Release the mutex
		 [T]Mutex Unlocked -> exit

       
Windows (Notice the 2nd Line they have written in the same time):
Execute sleep-thread
Wait thread to finish            [T]I am going to Sleep

                 [T]Okay I quit now
Thread has Finished
-----------------------------------------
Create and lock mutex
Start the second thread
Sleep (the thread is wainting the mutex :)               [T]Lock Mutex

Release the mutex
                 [T]Mutex Unlocked -> exit


*/
