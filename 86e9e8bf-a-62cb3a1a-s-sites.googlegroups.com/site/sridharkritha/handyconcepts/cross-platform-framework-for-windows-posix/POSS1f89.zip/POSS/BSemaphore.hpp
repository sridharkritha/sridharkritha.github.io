#ifndef BSEMAPHORE_HPP
#define BSEMAPHORE_HPP


// Use Win or Posix
#ifdef WINDOWS
	#include <windows.h>
	#define LMAXIMUMCOUNT 99999999 /**< Maximum semaphore value in Windows*/
#else
	#ifndef POSIX
		#warning POSIX will be used (but you did not define it)
	#endif
	#include <semaphore.h>
#endif


/**
* @author Berenger
* @version 0.5
* @date February 15 2010
* @file BSemaphore.hpp
* @package Package-OS specific (POSS)
* @brief Semaphore
*
*
* This class represent a simple way to use semaphore
*
* @must You may have to change this class if you are not on Windows
* @must or Posix OS
*
* All methods may be inlined by the compiler
* @copyright Brainable.Net
*/

class BSemaphore{
protected:

#ifdef WINDOWS
	HANDLE _sem;	/**< Win semaphore*/
#else
	sem_t _sem;		/**< Posix semaphore*/
#endif

public:
	/**
	* @brief Constructor
	* @param in_init original value
	*/
	BSemaphore( int in_init = 0 ){
	#ifdef WINDOWS
		_sem = CreateSemaphore(0,in_init,LMAXIMUMCOUNT,0); 
	#else
		sem_init(&_sem,0,in_init); 
	#endif
	}
	
	/**
	* @brief Copy constructor
	* @param in_sem original semaphore
	*/
	BSemaphore(const BSemaphore &in_sem){
		int value = in_sem.value();
	#ifdef WINDOWS
		_sem = CreateSemaphore(0,value,LMAXIMUMCOUNT,0); 
	#else
		sem_init(&_sem,0,value); 
	#endif
	}
	
	/**
	* @brief Copy method
	* @param in_sem original semaphore
	*/
	void operator=(const BSemaphore &in_sem){
		reset(in_sem.value());
	}
	
	
	/**
	* @brief destroy semaphore
	*/
	virtual ~BSemaphore(){ 
	#ifdef WINDOWS
		CloseHandle(_sem);
	#else
		sem_destroy(&_sem); 
	#endif
	}

	/**
	* @brief Wait until the semaphore is called by another thread
	* @return true if success or false if timeout or error
	*/
	bool wait() const { 
	#ifdef WINDOWS
		return WaitForSingleObject(static_cast< HANDLE >(_sem),INFINITE) == 0x00000000L;
	#else
		return sem_wait(const_cast<sem_t*>(&_sem)) == 0;
	#endif
	}
	
	/**
	* @brief post a token
	* @return true if success or false if error
	*/
	bool post(){ 
	#ifdef WINDOWS
		return ReleaseSemaphore(static_cast< HANDLE >(_sem),1,0) != 0;
	#else
		return sem_post(&_sem) == 0;
	#endif
	}
	
	/**
	* @brief get current value
	* @return value
	*/
	int value() const{ 
	#ifdef WINDOWS
		long value = -1;
		ReleaseSemaphore(static_cast<const HANDLE>(_sem),0,&value);
		return value;
	#else
		int value = -1;
		sem_getvalue(const_cast<sem_t*>(&_sem),&value);
		return value;
	#endif
	}

	/**
	* @brief release current semaphore and create a new one
	* @param init the value after reset
	*/
	void reset( int in_init = 0 ){ 
	#ifdef WINDOWS
		CloseHandle(_sem);
		_sem = CreateSemaphore(0,in_init,LMAXIMUMCOUNT,0);
	#else
		sem_destroy(&_sem);
		sem_init(&_sem,0,in_init);
	#endif

	}
};



#endif
